package com.robospana_test.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    public int
            matchNum, teamNum, alliColor, robotPosition,          // initialize robot information data
            autoCrossLine, autoSwitch, autoScale,                 // initialize Autonomous data
            teleSwitch, teleScale, teleOppSwitch, teleExchange,   // initialize Tele-Op data
            park, climb,                                          // initialize Endgame Data
            yellowCard, redCard;                                  // initialize Fouls / Cards Data

    public ToggleButton toggleAlliColor, toggleAutoCrossLn, toggleEndPark, toggleEndClimb, toggleEndYellowCard, toggleEndRedCard; // initialize all Toggle Buttons

    public TextView autoSwitchTV, autoScaleTV, teleSwitchTV, teleScaleTV, teleOppSwitchTV, teleExchangeTV, robotPositionTV; // initialize all TextViews (TVs)

    public EditText matchNumEditText, teamNumEditText; // initialize all EditTexts (Text boxes in which the user may enter data)

    public Switch resetSwitch; // initializes the switch which enables or disables the reset protection mechanism (which protects the user from mis-clicking reset)

    public String robotPositionStr; // initializes the string which will show the user his / her input on which position the robot is on

    @Override
    protected void onCreate(Bundle savedInstanceState) { // runs when app launches

        super.onCreate(savedInstanceState);
        setTitle("Cyber Spana 2019");         // sets the text on the action bar to the name of the app
        setContentView(R.layout.activity_main);

        // link all views (texts, buttons, switches) in java to their corresponding view in activity_main.xml by matching them with the id that is given in the xml
        toggleAlliColor = findViewById(R.id.toggleAllianceColor);
        toggleEndClimb = findViewById(R.id.toggleClimb);
        toggleEndPark = findViewById(R.id.togglePark);
        toggleEndYellowCard = findViewById(R.id.toggleYellowCard);
        toggleEndRedCard = findViewById(R.id.toggleRedCard);
        toggleAutoCrossLn = findViewById(R.id.toggleCrossLn);
        autoSwitchTV = findViewById(R.id.autoSwitchTV);
        autoScaleTV = findViewById(R.id.autoScaleTV);
        teleSwitchTV = findViewById(R.id.teleSwitchTV);
        teleScaleTV = findViewById(R.id.teleScaleTV);
        teleOppSwitchTV = findViewById(R.id.teleOppSwitchTV);
        teleExchangeTV = findViewById(R.id.teleExchangeTV);
        matchNumEditText = findViewById(R.id.matchNumber);
        teamNumEditText = findViewById(R.id.teamNumber);
        resetSwitch = findViewById(R.id.resetSwitch);
        robotPositionTV = findViewById(R.id.robotPositionTV);

        // set all data to their initial status
        autoSwitch = 0;
        autoScale = 0;
        teleSwitch = 0;
        teleScale = 0;
        teleOppSwitch = 0;
        teleExchange = 0;
        matchNum = 0;
        teamNum = 0;
        robotPosition = 0;
        resetSwitch.setChecked(true); // true means that the reset protection mechanism is enabled (switch is on ), therefore the use CANNOT reset
        robotPositionStr = "Position: Left";

    }

    // all the methods that controls what the buttons / switches do
    public void clickPlusAutoSwitch(View v){ // increments counter of Switch during Autonomous

        autoSwitch++;
        autoSwitchTV.setText( "Switch = "  + autoSwitch ); // refresh the TextView to match the update value

    }

    public void clickPlusAutoScale(View v){ // increments counter of Scale during Autonomous

        autoScale++;
        autoScaleTV.setText( "Scale = "  + autoScale ); // refresh the TextView to match the update value

    }

    public void clickPlusTeleSwitch(View v){ // increments counter of Switch during Tele-Op

        teleSwitch++;
        teleSwitchTV.setText( "Switch = "  + teleSwitch ); // refresh the TextView to match the update value

    }

    public void clickPlusTeleScale(View v){ // increments counter of Scale during Tele-Op

        teleScale++;
        teleScaleTV.setText( "Scale = "  + teleScale ); // refresh the TextView to match the update value

    }

    public void clickPlusTeleExchange(View v){ // increments counter of Exchange during Tele-Op

        teleExchange++;
        teleExchangeTV.setText( "Exchange = "  + teleExchange ); // refresh the TextView to match the update value

    }

    public void clickPlusTeleOppSwitch(View v){ // increments counter of Opponent's switch during Tele-Op

        teleOppSwitch++;
        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch ); // refresh the TextView to match the update value

    }

    public void clickMinusAutoSwitch(View v){ // decrements counter of Switch during Autonomous

        autoSwitch--;

        if(autoSwitch < 0){ // prevents the counter from going lower than 0

            autoSwitch = 0;

        }

        autoSwitchTV.setText( "Switch = "  + autoSwitch ); // refresh the TextView to match the update value

    }

    public void clickMinusAutoScale(View v){ // decrements counter of Scale during Autonomous

        autoScale--;
        if(autoScale < 0){ // prevents the counter from going lower than 0

            autoScale = 0;

        }

        autoScaleTV.setText( "Scale = "  + autoScale ); // refresh the TextView to match the update value

    }

    public void clickMinusTeleSwitch(View v){ // decrements counter of Switch during Tele-Op

        teleSwitch--;
        if(teleSwitch < 0){ // prevents the counter from going lower than 0

            teleSwitch = 0;

        }

        teleSwitchTV.setText( "Switch = "  + teleSwitch ); // refresh the TextView to match the update value

    }

    public void clickMinusTeleScale(View v){ // decrements counter of Scale during Tele-Op

        teleScale--;
        if(teleScale < 0){ // prevents the counter from going lower than 0

            teleScale = 0;

        }

        teleScaleTV.setText( "Scale = "  + teleScale ); // refresh the TextView to match the update value

    }

    public void clickMinusTeleExchange(View v){ // decrements counter of Exchange during Tele-Op

        teleExchange--;
        if(teleExchange < 0){ // prevents the counter from going lower than 0

            teleExchange = 0;

        }

        teleExchangeTV.setText( "Exchange = "  + teleExchange ); // refresh the TextView to match the update value

    }

    public void clickMinusTeleOppSwitch(View v){ // decrements counter of Opponent's Switch during Tele-Op

        teleOppSwitch--;
        if(teleOppSwitch < 0){ // prevents the counter from going lower than 0

            teleOppSwitch = 0;

        }

        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch ); // refresh the TextView to match the update value

    }

    public void clickRobotPosition(View V){

        robotPosition++;
        if (robotPosition > 2){  // prevents the counter from going higher than 2

            robotPosition = 0;

        }

        switch (robotPosition){ // 0 is left, 1 is middle, 2 is right
            case 0:

                robotPositionStr = "Position: Left";
                break;

            case 1:

                robotPositionStr = "Position: Middle";
                break;

            case 2:

                robotPositionStr = "Position: Right";
                break;

            default: // if something goes wrong with the counter and outputs a value that is not 0 , 1, or 2

                //display and error message as a toast to the user
                Toast.makeText(MainActivity.this, "A serious error has occurred, please contact James immediately", Toast.LENGTH_LONG);
                break;

        }

        robotPositionTV.setText(robotPositionStr); // displays the position on the TextView


    }



    public void clickSave(View v) {

        if( isEmpty(matchNumEditText) || isEmpty(teamNumEditText) ){ //check if the team number edit text or match number edit text is empty

            // if either of the two is empty, take no action but display the error message to the user to prevent the int from being given a invalid value
            // and therefore causing the app to crash
            Toast.makeText(MainActivity.this, "Error: Match Number and Team Number cannot be empty", Toast.LENGTH_SHORT).show();

        } else {

            // give each unsettled integer data its corresponding value
            matchNum = Integer.parseInt(matchNumEditText.getText().toString());
            teamNum = Integer.parseInt(teamNumEditText.getText().toString());
            alliColor = getToggleBooleanToInt( toggleAlliColor );
            autoCrossLine = getToggleBooleanToInt( toggleAutoCrossLn );
            park = getToggleBooleanToInt( toggleEndPark );
            climb = getToggleBooleanToInt( toggleEndClimb );
            yellowCard = getToggleBooleanToInt( toggleEndYellowCard );
            redCard = getToggleBooleanToInt( toggleEndRedCard );

            // convert the all data into a .txt file


            // give the user feedback so that they know that the save is successful
            Toast.makeText(MainActivity.this, "Saved!", Toast.LENGTH_SHORT).show();

        }



    }

    public void clickReset(View v) {

        boolean ready = !resetSwitch.isChecked(); // check if the reset mechanism is enabled (if the user is ready to reset all data)

        if(ready) {

            //reset all the values to original status
            autoSwitch = 0;
            autoScale = 0;
            teleSwitch = 0;
            teleScale = 0;
            teleOppSwitch = 0;
            teleExchange = 0;
            autoSwitchTV.setText( "Switch = "  + autoSwitch );
            autoScaleTV.setText( "Scale = "  + autoScale );
            teleSwitchTV.setText( "Switch = "  + teleSwitch );
            teleScaleTV.setText( "Scale = "  + teleScale );
            teleExchangeTV.setText( "Exchange = "  + teleExchange );
            teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );
            matchNumEditText.setText("");
            teamNumEditText.setText("");
            toggleAutoCrossLn.setChecked(false);
            toggleAlliColor.setChecked(false);
            toggleEndPark.setChecked(false);
            toggleEndClimb.setChecked(false);
            toggleEndYellowCard.setChecked(false);
            toggleEndRedCard.setChecked(false);
            resetSwitch.setChecked(true);

        } else{

            // prompt the user to disable the Reset Protection Mechanism if they are ready to reset all data
            Toast.makeText(MainActivity.this, "To reset, disable Reset Protection First!", Toast.LENGTH_SHORT).show();
        }
    }

    public int getToggleBooleanToInt( ToggleButton toggleButton ) { // a method to convert the booleans given by toggle switches to integers

        if(toggleButton.isChecked()){

            return 1;

        } else {

            return 0;

        }
        // "0"s are failures ( false booleans ) and "1"s are successes ( true booleans )

    }

    public boolean isEmpty(EditText etText) { // a method to check if an edit text is empty

        return etText.getText().toString().trim().length() == 0;

    }

}
