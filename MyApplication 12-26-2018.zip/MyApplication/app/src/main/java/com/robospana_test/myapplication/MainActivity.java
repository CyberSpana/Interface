package com.robospana_test.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    public int matchNum, teamNum,
            alliColor, autoCrossLine, autoSwitch, autoScale,
            teleSwitch, teleScale, teleOppSwitch, teleExchange,
            park, climb,yellowCard, redCard, robotPosition;

    public ToggleButton toggleAlliColor, toggleAutoCrossLn, toggleEndPark, toggleEndClimb, toggleEndYellowCard, toggleEndRedCard;

    public TextView autoSwitchTV, autoScaleTV, teleSwitchTV, teleScaleTV, teleOppSwitchTV, teleExchangeTV, robotPositionTV;

    public EditText matchNumEditText, teamNumEditText;

    public Switch resetSwitch;

    public String robotPositionStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setTitle("Cyber Spana 2018");
        setContentView(R.layout.activity_main);

        toggleAlliColor = findViewById(R.id.toggleAllianceColor);
        toggleEndClimb = findViewById(R.id.toggleClimb);
        toggleEndPark = findViewById(R.id.togglePark);
        toggleEndYellowCard = findViewById(R.id.toggleYellowCard);
        toggleEndRedCard = findViewById(R.id.toggleRedCard);
        toggleAutoCrossLn = findViewById(R.id.toggleCrossLn);
        autoSwitchTV = findViewById(R.id.autoSwitchTV);
        autoScaleTV = findViewById(R.id.autoScaleTV);
        teleSwitchTV = findViewById(R.id.teleSwitchTV);
        teleScaleTV = findViewById(R.id.teleScaleTV);
        teleOppSwitchTV = findViewById(R.id.teleOppSwitchTV);
        teleExchangeTV = findViewById(R.id.teleExchangeTV);
        matchNumEditText = findViewById(R.id.matchNumber);
        teamNumEditText = findViewById(R.id.teamNumber);
        resetSwitch = findViewById(R.id.resetSwitch);
        resetSwitch.setChecked(true);
        autoSwitch = 0;
        autoScale = 0;
        teleSwitch = 0;
        teleScale = 0;
        teleOppSwitch = 0;
        teleExchange = 0;
        matchNum = 0;
        teamNum = 0;
        robotPosition = 0;
        robotPositionStr = "Position: Left";
        robotPositionTV = findViewById(R.id.robotPositionTV);


    }

    public void clickPlusAutoSwitch(View v){

        autoSwitch++;
        autoSwitchTV.setText( "Switch = "  + autoSwitch );

    }

    public void clickPlusAutoScale(View v){

        autoScale++;
        autoScaleTV.setText( "Scale = "  + autoScale );

    }

    public void clickPlusTeleSwitch(View v){

        teleSwitch++;
        teleSwitchTV.setText( "Switch = "  + teleSwitch );

    }

    public void clickPlusTeleScale(View v){

        teleScale++;
        teleScaleTV.setText( "Scale = "  + teleScale );

    }

    public void clickPlusTeleExchange(View v){

        teleExchange++;
        teleExchangeTV.setText( "Exchange = "  + teleExchange );

    }

    public void clickPlusTeleOppSwitch(View v){

        teleOppSwitch++;
        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );

    }

    public void clickMinusAutoSwitch(View v){

        autoSwitch--;
        if(autoSwitch < 0){autoSwitch = 0;}
        autoSwitchTV.setText( "Switch = "  + autoSwitch );

    }

    public void clickMinusAutoScale(View v){

        autoScale--;
        if(autoScale < 0){autoScale = 0;}
        autoScaleTV.setText( "Scale = "  + autoScale );

    }

    public void clickMinusTeleSwitch(View v){

        teleSwitch--;
        if(teleSwitch < 0){teleSwitch = 0;}
        teleSwitchTV.setText( "Switch = "  + teleSwitch );

    }

    public void clickMinusTeleScale(View v){

        teleScale--;
        if(teleScale < 0){teleScale = 0;}
        teleScaleTV.setText( "Scale = "  + teleScale );

    }

    public void clickMinusTeleExchange(View v){

        teleExchange--;
        if(teleExchange < 0){teleExchange = 0;}
        teleExchangeTV.setText( "Exchange = "  + teleExchange );

    }

    public void clickMinusTeleOppSwitch(View v){

        teleOppSwitch--;
        if(teleOppSwitch < 0){teleOppSwitch = 0;}
        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );

    }

    public void clickRobotPosition(View V){

        robotPosition++;
        if (robotPosition > 2){
            robotPosition = 0;
        }
        switch (robotPosition){
            case 0:
                robotPositionStr = "Position: Left";
                break;
            case 1:
                robotPositionStr = "Position: Middle";
                break;
            case 2:
                robotPositionStr = "Position: Right";
                break;
            default:
                Toast.makeText(MainActivity.this, "A serious error has occurred, please contact James immediately", Toast.LENGTH_LONG);
                break;
        }

        robotPositionTV.setText(robotPositionStr);


    }



    public void clickSave(View v) {

        if( isEmpty(matchNumEditText) || isEmpty(teamNumEditText) ){

            Toast.makeText(MainActivity.this, "Error: Match Number and Team Number cannot be empty", Toast.LENGTH_SHORT).show();

        } else {

            matchNum = Integer.parseInt(matchNumEditText.getText().toString());
            teamNum = Integer.parseInt(teamNumEditText.getText().toString());
            alliColor = getToggleBooleanToInt( toggleAlliColor );
            autoCrossLine = getToggleBooleanToInt( toggleAutoCrossLn );
            park = getToggleBooleanToInt( toggleEndPark );
            climb = getToggleBooleanToInt( toggleEndClimb );
            yellowCard = getToggleBooleanToInt( toggleEndYellowCard );
            redCard = getToggleBooleanToInt( toggleEndRedCard );
            Toast.makeText(MainActivity.this, "Saved!", Toast.LENGTH_SHORT).show();

        }



    }

    public void clickReset(View v) {

        boolean ready = !resetSwitch.isChecked(); //reset switch is the protection mechanism that is designed to avoid mis-clicking the reset button and causing loss of critical information
        if(ready) {

            autoSwitch = 0;
            autoScale = 0;
            teleSwitch = 0;
            teleScale = 0;
            teleOppSwitch = 0;
            teleExchange = 0;
            autoSwitchTV.setText( "Switch = "  + autoSwitch );
            autoScaleTV.setText( "Scale = "  + autoScale );
            teleSwitchTV.setText( "Switch = "  + teleSwitch );
            teleScaleTV.setText( "Scale = "  + teleScale );
            teleExchangeTV.setText( "Exchange = "  + teleExchange );
            teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );
            matchNumEditText.setText("");
            teamNumEditText.setText("");
            toggleAutoCrossLn.setChecked(false);
            toggleAlliColor.setChecked(false);
            toggleEndPark.setChecked(false);
            toggleEndClimb.setChecked(false);
            toggleEndYellowCard.setChecked(false);
            toggleEndRedCard.setChecked(false);
            resetSwitch.setChecked(true);

        } else{

            Toast.makeText(MainActivity.this, "Disable Reset Protection First!", Toast.LENGTH_SHORT).show();
        }
    }

    public int getToggleBooleanToInt( ToggleButton toggleButton ) {

        if(toggleButton.isChecked()){
            return 1;
        } else {
            return 0;
        }
        // 0 are failures and 1 ones are successes

    }

    private boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }

}
