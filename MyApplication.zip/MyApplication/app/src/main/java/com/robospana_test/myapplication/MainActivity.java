package com.robospana_test.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    public int matchNum, teamNum,
            alliColor, autoCrossLine, autoSwitch, autoScale,
            teleSwitch, teleScale, teleOppSwitch, teleExchange,
            park, climb,yellowCard, redCard;

    public ToggleButton toggleAlliColor, toggleAutoCrossLn, toggleEndPark, toggleEndClimb, toggleEndYellowCard, toggleEndRedCard;

    public TextView autoSwitchTV, autoScaleTV, teleSwitchTV, teleScaleTV, teleOppSwitchTV, teleExchangeTV;

    public EditText matchNumEditText, teamNumEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleAlliColor = findViewById(R.id.toggleAllianceColor);
        toggleEndClimb = findViewById(R.id.toggleClimb);
        toggleEndPark = findViewById(R.id.togglePark);
        toggleEndYellowCard = findViewById(R.id.toggleYellowCard);
        toggleEndRedCard = findViewById(R.id.toggleRedCard);
        toggleAutoCrossLn = findViewById(R.id.toggleCrossLn);
        autoSwitchTV = findViewById(R.id.autoSwitchTV);
        autoScaleTV = findViewById(R.id.autoScaleTV);
        teleSwitchTV = findViewById(R.id.teleSwitchTV);
        teleScaleTV = findViewById(R.id.teleScaleTV);
        teleOppSwitchTV = findViewById(R.id.teleOppSwitchTV);
        teleExchangeTV = findViewById(R.id.teleExchangeTV);
        matchNumEditText = findViewById(R.id.matchNumber);
        teamNumEditText = findViewById(R.id.teamNumber);
        autoSwitch = 0;
        autoScale = 0;
        teleSwitch = 0;
        teleScale = 0;
        teleOppSwitch = 0;
        teleExchange = 0;
        matchNum = 0;
        teamNum = 0;


    }

    public void clickPlusAutoSwitch(View v){

        autoSwitch++;
        autoSwitchTV.setText( "Switch = "  + autoSwitch );

    }

    public void clickPlusAutoScale(View v){

        autoScale++;
        autoScaleTV.setText( "Scale = "  + autoScale );

    }

    public void clickPlusTeleSwitch(View v){

        teleSwitch++;
        teleSwitchTV.setText( "Switch = "  + teleSwitch );

    }

    public void clickPlusTeleScale(View v){

        teleScale++;
        teleScaleTV.setText( "Scale = "  + teleScale );

    }

    public void clickPlusTeleExchange(View v){

        teleExchange++;
        teleExchangeTV.setText( "Exchange = "  + teleExchange );

    }

    public void clickPlusTeleOppSwitch(View v){

        teleOppSwitch++;
        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );

    }

    public void clickMinusAutoSwitch(View v){

        autoSwitch--;
        autoSwitchTV.setText( "Switch = "  + autoSwitch );

    }

    public void clickMinusAutoScale(View v){

        autoScale--;
        autoScaleTV.setText( "Scale = "  + autoScale );

    }

    public void clickMinusTeleSwitch(View v){

        teleSwitch--;
        teleSwitchTV.setText( "Switch = "  + teleSwitch );

    }

    public void clickMinusTeleScale(View v){

        teleScale--;
        teleScaleTV.setText( "Scale = "  + teleScale );

    }

    public void clickMinusTeleExchange(View v){

        teleExchange--;
        teleExchangeTV.setText( "Exchange = "  + teleExchange );

    }

    public void clickMinusTeleOppSwitch(View v){

        teleOppSwitch--;
        teleOppSwitchTV.setText( "Opp. Switch = "  + teleOppSwitch );

    }



    public void clickSave(View v) {

        matchNum = Integer.parseInt(matchNumEditText.getText().toString());
        teamNum = Integer.parseInt(teamNumEditText.getText().toString());
        alliColor = getToggleBooleanToInt( toggleAlliColor );
        autoCrossLine = getToggleBooleanToInt( toggleAutoCrossLn );
        park = getToggleBooleanToInt( toggleEndPark );
        climb = getToggleBooleanToInt( toggleEndClimb );
        yellowCard = getToggleBooleanToInt( toggleEndYellowCard );
        redCard = getToggleBooleanToInt( toggleEndRedCard );

    }

    public void clickReset(View v) {

        autoSwitch = 0;
        autoScale = 0;
        teleSwitch = 0;
        teleScale = 0;
        teleOppSwitch = 0;
        teleExchange = 0;
        autoSwitchTV.setText( "Switch = "  + autoSwitch );
        autoScaleTV.setText( "Switch = "  + autoScale );
        teleSwitchTV.setText( "Switch = "  + teleSwitch );
        teleScaleTV.setText( "Switch = "  + teleScale );
        teleExchangeTV.setText( "Switch = "  + teleExchange );
        teleOppSwitchTV.setText( "Switch = "  + teleOppSwitch );
        matchNumEditText.setText("");
        teamNumEditText.setText("");
        toggleAutoCrossLn.setChecked(false);
        toggleAlliColor.setChecked(false);
        toggleEndPark.setChecked(false);
        toggleEndClimb.setChecked(false);
        toggleEndYellowCard.setChecked(false);
        toggleEndRedCard.setChecked(false);
    }

    public int getToggleBooleanToInt( ToggleButton toggleButton ) {

        if(toggleButton.isChecked()){
            return 1;
        } else {
            return 0;
        }

    }

}
